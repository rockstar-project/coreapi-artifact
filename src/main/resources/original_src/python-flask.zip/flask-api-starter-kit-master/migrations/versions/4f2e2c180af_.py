"""Initial migration

Revision ID: 4f2e2c180af
Revises: None
Create Date: 2016-01-15 15:09:02.084174

"""

from alembic import op
import sqlalchemy as sa

revision = '4f2e2c180af'
down_revision = None


def upgrade():
    pass


def downgrade():
    pass
